uart.o: uart.c
uart.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
uart.o: Type.h
uart.o: defines.h
uart.o: pin_function_defines.h
uart.o: uart_defines.h

i2c.o: i2c.c
i2c.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
i2c.o: Type.h
i2c.o: delay.h
i2c.o: i2c_defines.h
i2c.o: pin_function_defines.h

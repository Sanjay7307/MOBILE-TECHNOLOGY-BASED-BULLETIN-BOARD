i2c_eeprom.o: i2c_eeprom.c
i2c_eeprom.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
i2c_eeprom.o: type.h
i2c_eeprom.o: i2c.h
i2c_eeprom.o: Type.h
i2c_eeprom.o: delay.h
i2c_eeprom.o: C:\KeilARM\ARM\RV31\INC\string.h

uart_int.o: uart_int.c
uart_int.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
uart_int.o: uart0.h
uart_int.o: pin_function_defines.h

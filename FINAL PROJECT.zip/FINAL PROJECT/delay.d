delay.o: delay.c

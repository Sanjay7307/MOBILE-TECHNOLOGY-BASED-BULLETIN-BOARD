uart_main.o: uart_main.c
uart_main.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
uart_main.o: C:\KeilARM\ARM\RV31\INC\string.h
uart_main.o: delay.h
uart_main.o: uart.h
uart_main.o: Type.h

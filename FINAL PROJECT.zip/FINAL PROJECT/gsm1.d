.\gsm1.o: gsm1.c
.\gsm1.o: C:\Keil_v5\ARM\ARMCC\bin\..\include\string.h
.\gsm1.o: uart0.h
.\gsm1.o: delay.h
.\gsm1.o: C:\Keil_v5\ARM\Inc\Philips\LPC21xx.h
.\gsm1.o: i2c_eeprom.h
.\gsm1.o: Type.h
.\gsm1.o: lcd.h

main.o: main.c
main.o: gsm2.h
